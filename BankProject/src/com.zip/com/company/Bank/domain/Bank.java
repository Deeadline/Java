package com.company.Bank.domain;

import java.util.ArrayList;
import java.util.List;

public class Bank {
    private static Bank bankInstance = null;

    public static Bank getBankInstance() {
        if (bankInstance == null) {
            bankInstance = new Bank();
        }
        return bankInstance;
    }

    private Bank() {
    }

    final private String bankName = "MBANK POLSKA";
    private List<BankAccount> bankAccountList = new ArrayList<>();

    public List<BankAccount> getBankAccountList() {
        return bankAccountList;
    }

    public void addAccount(BankAccount bankAccount) {
        bankAccountList.add(bankAccount);
    }

    public String getName() {
        return bankName;
    }
}
